/***************************************************************************
    data_results_epsg32642.gpkg
        begin                : 2021-11
        copyright            : (C) 2021 by Giacomo Titti, Luigi Lombardo, Cees van Westen
                               Bologna, November 2021
        email                : giacomotitti@gmail.com
 ***************************************************************************/

This dataset has been produced by Giacomo Titti, Luigi Lombardo, Cees van Westen.

For use, please cite: Giacomo Titti, Cees van Westen, Lisa Borgatti, Alessandro Pasuto, Luigi Lombardo (2021). When Enough Is Really Enough? On the Minimum Number of Landslides to Build Reliable Susceptibility Models. Geosciences. 

